//
//  BluetoothController.swift
//  uwbtestapp
//
//  Created by David Umanzor on 11/26/22.
//

import UIKit
import CoreBluetooth
import SwiftUI
import CocoaMQTT
import AVFoundation
import AudioToolbox

extension Array where Element: BinaryFloatingPoint {

    /// The average value of all the items in the array
    var average: Double {
        if self.isEmpty {
            return 0.0
        } else {
            let sum = self.reduce(0, +)
            return Double(sum) / Double(self.count)
        }
    }

}

class BluetoothController: UIViewController, CBPeripheralDelegate, CBCentralManagerDelegate, AVAudioPlayerDelegate {
    
    let contentView = UIHostingController(rootView: ContentView())
    
    var mqtt5: CocoaMQTT5?
    let controlTopic = "t/sd/uwb"

    func mqttSetting() {
        let clientID = "CocoaMQTT-" + String(ProcessInfo().processIdentifier)
        let websocket = CocoaMQTTWebSocket(uri: "/mqtt")
        mqtt5 = CocoaMQTT5(clientID: clientID, host: "broker.emqx.io", port: 8083, socket: websocket)

        let connectProperties = MqttConnectProperties()
        connectProperties.topicAliasMaximum = 0
        connectProperties.sessionExpiryInterval = 0
        connectProperties.receiveMaximum = 100
        connectProperties.maximumPacketSize = 500

        mqtt5!.connectProperties = connectProperties

        mqtt5!.username = ""
        mqtt5!.password = ""

        let lastWillMessage = CocoaMQTT5Message(topic: "/will", string: "dieout")
        lastWillMessage.contentType = "JSON"
        lastWillMessage.willExpiryInterval = .max
        lastWillMessage.willDelayInterval = 0
        lastWillMessage.qos = .qos1

        mqtt5!.willMessage = lastWillMessage
        mqtt5!.keepAlive = 60
        mqtt5!.delegate = self
    }
        
    @objc func relaunchMQTT(){
        mqttSetting()

        if let mqtt5 = mqtt5 {
            if(mqtt5.connect())
            {
                print("connect ok")
            }
        }
    }
    
    @IBOutlet weak var LemonBeaconText: UILabel!
    @IBOutlet weak var CoconutBeaconText: UILabel!
    @IBOutlet weak var CaramelBeaconText: UILabel!
    @IBOutlet weak var LocalizationText: UILabel!
    
    var timeLaunchedLemon: Int = 0
    var timeLaunchedCoconut: Int = 0
    var timeLaunchedCaramel: Int = 0
    var timer: Timer?
    static let UWB = UWBManagerExample()
    var beaconlemonarray = [Float]()
    var beaconcoconutarray = [Float]()
    var beaconcaramelarray = [Float]()
    var beaconlemonavgdistance: Double = 0.0
    var beaconcoconutavgdistance: Double = 0.0
    var beaconcaramelavgdistance: Double = 0.0
    
    @objc func updateLocalizationLabel(){
        if ContentView.localization == 0
        {
            LocalizationText.text = "Localization stopped"
        }
        else if ContentView.localization == 1
        {
            LocalizationText.text = "Localization in progress"
        }
    }
    
    @objc func checkButtonPress(){
        if ContentView.buttonpressed == true{
            ContentView.buttonpressed = false
            if ContentView.localization == 0
            {
                PlaySound(code: "LS")
            }
            else if ContentView.localization == 1
            {
                PlaySound(code: "LP")
            }
        }
    }
        
    @objc func playLocalizationSound(){
        if ContentView.localization == 0
        {
            PlaySound(code: "LS")
        }
        else if ContentView.localization == 1
        {
            PlaySound(code: "LP")
        }
    }
    

    @objc func updateLemonLabel() {
       //BeaconText.text = " Time Launched = \(timeLaunched) Seconds "

        timeLaunchedLemon += 1
        beaconlemonarray.append(BluetoothController.UWB.beaconlemondistance)
        if timeLaunchedLemon == 3 {
            beaconlemonavgdistance = beaconlemonarray.average
            LemonBeaconText.text = "Distance from Lemon Beacon is " + (NSString(format: "%.2f", beaconlemonavgdistance) as String) + " m" as String
            beaconlemonarray.removeAll()
            timeLaunchedLemon = 0
        }
        }

    @objc func updateCoconutLabel() {
       //BeaconText.text = " Time Launched = \(timeLaunched) Seconds "
        timeLaunchedCoconut += 1
        beaconcoconutarray.append(BluetoothController.UWB.beaconcoconutdistance)
        if timeLaunchedCoconut == 3 {
            beaconcoconutavgdistance = beaconcoconutarray.average
            CoconutBeaconText.text = "Distance from Coconut Beacon is " + (NSString(format: "%.2f", beaconcoconutavgdistance) as String) + " m" as String
            beaconcoconutarray.removeAll()
            timeLaunchedCoconut = 0
        }
        }
    
    @objc func updateCaramelLabel() {
       //BeaconText.text = " Time Launched = \(timeLaunched) Seconds "
        timeLaunchedCaramel += 1
        beaconcaramelarray.append(BluetoothController.UWB.beaconcarameldistance)
        if timeLaunchedCaramel == 3 {
            beaconcaramelavgdistance = beaconcaramelarray.average
            CaramelBeaconText.text = "Distance from Caramel Beacon is " + (NSString(format: "%.2f", beaconcaramelavgdistance) as String) + " m" as String
            beaconcaramelarray.removeAll()
            timeLaunchedCaramel = 0
        }
        }
    
    @objc func sendMQTTMessage() {
        let distmsg = "{\"dist\": \"\(beaconlemonavgdistance), \(beaconcoconutavgdistance), \(beaconcaramelavgdistance)\"}"
        //let buf: [UInt8] = Array(distmsg.utf8)
        //let msg = CocoaMQTT5Message(topic: controlTopic, payload: buf)
        let publishProperties = MqttPublishProperties()
        if let mqtt5 = mqtt5 {
            mqtt5.publish("t/sd/uwb", withString: distmsg, qos: .qos1, DUP: false, retained: false, properties: publishProperties)
        }
    }

    var centralManager: CBCentralManager!
    private var discPeripheral: CBPeripheral!

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
        switch central.state {
             case .poweredOff:
                 print("Is Powered Off.")
                let alertVC = UIAlertController(title: "Bluetooth Required", message: "Check your Bluetooth Settings", preferredStyle: UIAlertController.Style.alert)

                let action = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { (action: UIAlertAction) -> Void in
                    self.dismiss(animated: true, completion: nil)
                })

            alertVC.addAction(action)

            self.present(alertVC, animated: true, completion: nil)
             case .poweredOn:
                 print("Is Powered On.")
                 //startScanning()
             case .unsupported:
                 print("Is Unsupported.")
             case .unauthorized:
             print("Is Unauthorized.")
             case .unknown:
                 print("Unknown")
             case .resetting:
                 print("Resetting")
             @unknown default:
               print("Error")
             }
        
        func startScanning() -> Void {
          // Start Scanning
          centralManager?.scanForPeripherals(withServices: nil)
        }
        
    }
    
    var audioPlayer: AVAudioPlayer! = nil
    
    var feedbackSound = Bundle.main.path(forResource: "cornertable", ofType: "mp3")!
    func PlaySound(code: String) {
        AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))

        switch code {
        case "CT":
            feedbackSound = Bundle.main.path(forResource: "cornertable", ofType: "mp3")!
        case "GO":
            feedbackSound = Bundle.main.path(forResource: "gameover", ofType: "mp3")!
        case "RL":
            feedbackSound = Bundle.main.path(forResource: "rightlocation", ofType: "mp3")!
        case "SM":
            feedbackSound = Bundle.main.path(forResource: "startmoving", ofType: "mp3")!
        case "L":
            feedbackSound = Bundle.main.path(forResource: "toleft", ofType: "mp3")!
        case "R":
            feedbackSound = Bundle.main.path(forResource: "toright", ofType: "mp3")!
        case "LP":
            feedbackSound = Bundle.main.path(forResource: "localizationprogress", ofType: "mp3")!
        case "LS":
            feedbackSound = Bundle.main.path(forResource: "localizationstopped", ofType: "mp3")!
        default:
            return
        }
        
        let soundURL = URL(fileURLWithPath: feedbackSound)
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback)
            try AVAudioSession.sharedInstance().setActive(true)
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer.prepareToPlay()
            audioPlayer.delegate = self
            audioPlayer.play()
        } catch _ {
            print("Sound failed to play")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        contentView.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(contentView.view)
        contentView.didMove(toParent: self)

        NSLayoutConstraint.activate([
            contentView.view.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0),
            contentView.view.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.6),
        ])
        

        
        updateLemonLabel()
        updateCoconutLabel()
        updateCaramelLabel()
        updateLocalizationLabel()
        //sendMQTTMessage()
        NotificationCenter.default.addObserver(self, selector: #selector(relaunchMQTT), name: UIApplication.willEnterForegroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(playLocalizationSound), name: UIApplication.willEnterForegroundNotification, object: nil)
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(BluetoothController.updateLemonLabel)), userInfo: nil, repeats: true)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(BluetoothController.updateCoconutLabel)), userInfo: nil, repeats: true)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(BluetoothController.updateCaramelLabel)), userInfo: nil, repeats: true)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(BluetoothController.updateLocalizationLabel)), userInfo: nil, repeats: true)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(BluetoothController.sendMQTTMessage)), userInfo: nil, repeats: true)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(BluetoothController.checkButtonPress)), userInfo: nil, repeats: true)
        //centralManager = CBCentralManager(delegate: self, queue: nil)


    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        BluetoothController.UWB.setupUWB()
        //mqtt5?.ping()
        mqttSetting()
        if let mqtt5 = mqtt5 {
            if(mqtt5.connect())
            {
                print("connect ok")
            }
        }
        PlaySound(code: "LP")
    }
    
}

extension BluetoothController {
    func TRACE(_ message: String = "", fun: String = #function) {
        let names = fun.components(separatedBy: ":")
        var prettyName: String
        if names.count == 2 {
            prettyName = names[0]
        } else {
            prettyName = names[1]
        }
        
        if fun == "mqttDidDisconnect(_:withError:)" {
            prettyName = "didDisconnect"
        }

        print("[TRACE] [\(prettyName)]: \(message)")
    }
}

extension BluetoothController: CocoaMQTT5Delegate {
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didReceiveDisconnectReasonCode reasonCode: CocoaMQTTDISCONNECTReasonCode) {
        print("disconnect res : \(reasonCode)")
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didReceiveAuthReasonCode reasonCode: CocoaMQTTAUTHReasonCode) {
        print("auth res : \(reasonCode)")
    }
    
    // Optional ssl CocoaMQTT5Delegate
    func mqtt5(_ mqtt5: CocoaMQTT5, didReceive trust: SecTrust, completionHandler: @escaping (Bool) -> Void) {
        TRACE("trust: \(trust)")
        /// Validate the server certificate
        ///
        /// Some custom validation...
        ///
        /// if validatePassed {
        ///     completionHandler(true)
        /// } else {
        ///     completionHandler(false)
        /// }
        completionHandler(true)
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didConnectAck ack: CocoaMQTTCONNACKReasonCode, connAckData: MqttDecodeConnAck?) {
        TRACE("ack: \(ack)")

        if ack == .success {
            if(connAckData != nil){
                print("properties maximumPacketSize: \(String(describing: connAckData!.maximumPacketSize))")
                print("properties topicAliasMaximum: \(String(describing: connAckData!.topicAliasMaximum))")
            }

            mqtt5.subscribe("t/sd/uwb", qos: CocoaMQTTQoS.qos0)
            mqtt5.subscribe("t/sd/feedback", qos: CocoaMQTTQoS.qos0)
        }
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didStateChangeTo state: CocoaMQTTConnState) {
        TRACE("new state: \(state)")
        if state == .disconnected {

        }
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didPublishMessage message: CocoaMQTT5Message, id: UInt16) {
        TRACE("message: \(message.description), id: \(id)")
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didPublishAck id: UInt16, pubAckData: MqttDecodePubAck?) {
        TRACE("id: \(id)")
        if(pubAckData != nil){
            print("pubAckData reasonCode: \(String(describing: pubAckData!.reasonCode))")
        }
    }

    func mqtt5(_ mqtt5: CocoaMQTT5, didPublishRec id: UInt16, pubRecData: MqttDecodePubRec?) {
        TRACE("id: \(id)")
        if(pubRecData != nil){
            print("pubRecData reasonCode: \(String(describing: pubRecData!.reasonCode))")
        }
    }

    func mqtt5(_ mqtt5: CocoaMQTT5, didPublishComplete id: UInt16,  pubCompData: MqttDecodePubComp?){
        TRACE("id: \(id)")
        if(pubCompData != nil){
            print("pubCompData reasonCode: \(String(describing: pubCompData!.reasonCode))")
        }
    }

    func mqtt5(_ mqtt5: CocoaMQTT5, didReceiveMessage message: CocoaMQTT5Message, id: UInt16, publishData: MqttDecodePublish?){
//        if(publishData != nil){
//            print("publish.contentType \(String(describing: publishData!.contentType))")
//        }
//
//        TRACE("message: \(message.string?.description), id: \(id)")
//        let name = NSNotification.Name(rawValue: "MQTTMessageNotification")
//
//        NotificationCenter.default.post(name: name, object: self, userInfo: ["message": message.string!, "topic": message.topic, "id": id])
        let messageDecoded = String(bytes: message.payload, encoding: .utf8)
        print("Received message: \(messageDecoded!)")
        if message.topic == "t/sd/feedback" {
            PlaySound(code: messageDecoded ?? "")
        }
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didSubscribeTopics success: NSDictionary, failed: [String], subAckData: MqttDecodeSubAck?) {
        TRACE("subscribed: \(success), failed: \(failed)")
        if(subAckData != nil){
            print("subAckData.reasonCodes \(String(describing: subAckData!.reasonCodes))")
        }
    }
    
    func mqtt5(_ mqtt5: CocoaMQTT5, didUnsubscribeTopics topics: [String], UnsubAckData: MqttDecodeUnsubAck?) {
        TRACE("topic: \(topics)")
        if(UnsubAckData != nil){
            print("UnsubAckData.reasonCodes \(String(describing: UnsubAckData!.reasonCodes))")
        }
        print("----------------------")
    }
    
    func mqtt5DidPing(_ mqtt5: CocoaMQTT5) {
        TRACE()
    }
    
    func mqtt5DidReceivePong(_ mqtt5: CocoaMQTT5) {
        TRACE()
    }

    func mqtt5DidDisconnect(_ mqtt5: CocoaMQTT5, withError err: Error?) {
        TRACE("\(err)")
        let name = NSNotification.Name(rawValue: "MQTTMessageNotificationDisconnect")
        NotificationCenter.default.post(name: name, object: nil)
    }
}

