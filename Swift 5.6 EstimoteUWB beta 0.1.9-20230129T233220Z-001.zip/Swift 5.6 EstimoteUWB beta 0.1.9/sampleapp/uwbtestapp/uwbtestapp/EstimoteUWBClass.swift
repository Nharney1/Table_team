//
//  EstimoteUWBClass.swift
//  uwbtestapp
//
//  Created by David Umanzor on 11/13/22.
//

import Foundation
import EstimoteUWB
import EstimoteUWB.Swift
import EstimoteUWB.Private

class UWBManagerExample {

    var uwbManager: EstimoteUWBManager?
    var uwbDevice:UWBDevice?
    var beaconlemonid: String
    var beaconcaramelid: String
    var beaconcoconutid: String
    var beaconlemondistance: Float = 0
    var beaconcarameldistance: Float = 0
    var beaconcoconutdistance: Float = 0

    init() {
        self.beaconlemonid = "989b7dbc92970f18e6af0d0e0e38fb33"
        self.beaconcaramelid = "337580dcfa2db996c5d1ee780f241304"
        self.beaconcoconutid = "75c2cdc9951fcb641c5ccead91dad725"
    }
    
    func setupUWB() {
        uwbManager = EstimoteUWBManager(positioningObserver: self, discoveryObserver: self, beaconRangingObserver: self)
        uwbManager?.startScanning()
    }
    
}

// REQUIRED PROTOCOL
extension UWBManagerExample: UWBPositioningObserver {
    
    func didUpdatePosition(for device: UWBDevice){
        //print("position updated now for device: \(device)")
        switch device.publicId {
        case beaconlemonid:
            self.beaconlemondistance = device.distance
        case beaconcaramelid:
            self.beaconcarameldistance = device.distance
        case beaconcoconutid:
            self.beaconcoconutdistance = device.distance
        default:
            print("New beacon found")
        }
    }
}

// OPTIONAL PROTOCOL FOR BEACON BLE RANGING
extension UWBManagerExample: BeaconRangingObserver {
    func didRange(for beacon: BLEDevice) {
//        print("beacon did range: \(beacon)")
    }
}

// OPTIONAL PROTOCOL FOR DISCOVERY AND CONNECTIVITY CONTROL
extension UWBManagerExample: UWBDiscoveryObserver {
    var shouldConnectAutomatically: Bool {
        return true // set this to false if you want to manage when and what devices to connect to for positioning updates
    }
    
    func didDiscover(device: UWBIdentifable, with rssi: NSNumber, from manager: EstimoteUWBManager) {
        print("Discovered Device: \(device.publicId) rssi: \(rssi)")
        
        // if shouldConnectAutomatically is set to false - then you could call manager.connect(to: device)
        // additionally you can globally call discoonect from the scope where you have inititated EstimoteUWBManager -> disconnect(from: device) or disconnect(from: publicId)
    }
    
    func didConnect(to device: UWBIdentifable) {
        print("Successfully Connected to: \(device.publicId)")
    }
    
    func didDisconnect(from device: UWBIdentifable, error: Error?) {
        print("Disconnected from device: \(device.publicId)- error: \(String(describing: error))")

    }
    
    func didFailToConnect(to device: UWBIdentifable, error: Error?) {
        print("Failed to conenct to: \(device.publicId) - error: \(String(describing: error))")
    }
}
