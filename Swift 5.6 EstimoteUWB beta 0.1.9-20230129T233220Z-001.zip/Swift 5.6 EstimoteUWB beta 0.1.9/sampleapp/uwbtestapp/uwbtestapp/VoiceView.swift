//
//  VoiceView.swift
//  uwbtestapp
//
//  Created by David Umanzor on 11/13/22.
//

import SwiftUI

struct VoiceView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct VoiceView_Previews: PreviewProvider {
    static var previews: some View {
        VoiceView()
    }
}
