import SwiftUI
import EstimoteUWB
import EstimoteUWB.Private
import EstimoteUWB.Swift
import SwiftSpeech

struct ContentView: View {
    static var localization: Int = 1
    static var buttonpressed: Bool = false
    var body: some View {
        VStack(alignment: .center){
            Image("VisionAppIcon")
                .multilineTextAlignment(.center)
                .navigationViewStyle(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Navigation View Style@*/DefaultNavigationViewStyle()/*@END_MENU_TOKEN@*/)
            Text("SENIOR DESIGN APP")
                .fontWeight(.bold)
                .foregroundColor(Color.blue)
                .multilineTextAlignment(.leading)
                .font(.title)
            //Divider()
            Button (action: {
                print("Play Button pressed")
                BluetoothController.UWB.setupUWB()
                ContentView.localization = 1
                ContentView.buttonpressed = true
            })
            {
                HStack(alignment: .center){
                    Image("Playbutton").resizable()
                        .aspectRatio(contentMode: .fit)
                        .font(.title)
                    Text("Start UWB Localization")
                        .fontWeight(.semibold)
                }
            }
            .contentShape(Rectangle())
            .buttonStyle(GradientBackgroundStyle())

            Button (action: {
                print("Stop Button pressed")
                BluetoothController.UWB.uwbManager?.stopScanning()
                ContentView.localization = 0
                ContentView.buttonpressed = true
            })
            {
                HStack(alignment: .center){
                    Image("Stopbutton").resizable()
                        .aspectRatio(contentMode: .fit)
                        .font(.title)
                    Text("Stop UWB Localization")
                        .fontWeight(.semibold)
                }
            }
            .contentShape(Rectangle())
            .buttonStyle(GradientBackgroundStyle())
            
                
                //Group {
                //  SwiftSpeech.Demos.Basic(localeIdentifier: "en_US")
                //}
            
        }
    }
}


func HTTPPost() -> Void {
    // Prepare URL
    let url = URL(string: "http://127.0.0.1:8010")
    guard let requestUrl = url else { fatalError() }

    // Prepare URL Request Object
    var request = URLRequest(url: requestUrl)
    request.httpMethod = "POST"

    // HTTP Request Parameters which will be sent in HTTP Request Body
    let postString = "userId=300&title=SeniorDesign&completed=false";

    // Set HTTP Request Body
    request.httpBody = postString.data(using: String.Encoding.utf8);

    // Perform HTTP Request
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            // Check for Error
            if let error = error {
                print("Error took place \(error)")
                return
            }
     
            // Convert HTTP Response Data to a String
            if let data = data, let dataString = String(data: data, encoding: .utf8) {
                print("Response data string:\n \(dataString)")
            }
    }
    task.resume()
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct GradientBackgroundStyle: ButtonStyle {
 
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 200)
            .padding(10)
            .foregroundColor(.white)
            .background(configuration.isPressed ?
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.red]), startPoint: .leading, endPoint: .trailing)
                        :
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(40)
    }
}

struct StoryboardViewController: UIViewControllerRepresentable {
    
    func makeUIViewController(context: Context) -> some UIViewController {
        let storyboard = UIStoryboard(name: "BluetoothController", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "BluetoothController")
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        
    }
}

