//
//  uwbtestappApp.swift
//  uwbtestapp
//
//  Created by DJ HAYDEN on 1/14/22.
//

import SwiftUI

@main
struct uwbtestappApp: App {
    var body: some Scene {
        WindowGroup {
            StoryboardViewController()
        }
    }
}

 
